#!/bin/bash
su -c '
# ========================================================
# Enhanced System Hardening Script for Arch Linux (Non-systemd)
# Optimized for gaming PCs with P2P, gaming, and developer needs
# ========================================================

# Function for applying config files with improved error handling
apply_config() {
    local source_file="confs/$1"
    local target_file="$2"
    
    if [ ! -f "$source_file" ]; then
        echo "Warning: Configuration file $source_file not found - skipping"
        return 0
    fi
    
    if ! cat "$source_file" > "$target_file" 2>/dev/null; then
        echo "Warning: Failed to apply $source_file to $target_file - skipping"
        return 0
    fi
    
    echo "Successfully applied $source_file to $target_file"
    return 0
}

# Print section header for better readability
print_section() {
    echo "================================================================"
    echo "  $1"
    echo "================================================================"
}

print_section "Starting system hardening process..."

# ========================================================
# FILE PERMISSIONS
# ========================================================
print_section "Setting secure file permissions..."
chmod 700 /root
chmod 600 /etc/shadow
chmod 600 /etc/gshadow
chmod 644 /etc/passwd
chmod 644 /etc/group
chmod 600 /etc/sudoers
chmod -R 700 /etc/ssl/private
chmod -R 755 /etc/ssl/certs

# Verify important file permissions
find /etc/cron.* -type f -exec chmod 0700 {} \;
chmod 0600 /etc/crontab
chmod 0600 /etc/ssh/sshd_config 2>/dev/null
chmod -R 0700 /etc/ssl/private 2>/dev/null

# ========================================================
# UFW CONFIGURATION
# ========================================================
print_section "Configuring UFW..."
ufw limit 22/tcp  
ufw allow 80/tcp  
ufw allow 443/tcp  
# P2P and Gaming ports
ufw allow 6881:6889/tcp  # Standard BitTorrent
ufw allow 6881:6889/udp
ufw allow 27000:27100/tcp  # Steam
ufw allow 27000:27100/udp
ufw allow 3478:3480/tcp   # PlayStation/Xbox
ufw allow 3478:3480/udp
# Tor ports
ufw allow 9050/tcp
ufw allow 9051/tcp
ufw allow 9150/tcp
ufw default deny incoming  
ufw default allow outgoing
ufw enable

# ========================================================
# HOST CONFIGURATION
# ========================================================
print_section "Configuring host settings..."
cat <<EOF > /etc/host.conf
order bind,hosts
multi on
EOF

# Display listening ports for reference
echo "Current listening ports (for reference):"
netstat -tunlp

# ========================================================
# INITIALIZE FIREWALL VARIABLES
# ========================================================
IPTABLES="/sbin/iptables"
IP6TABLES="/sbin/ip6tables"
MODPROBE="/sbin/modprobe"
RMMOD="/sbin/rmmod"
ARP="/usr/sbin/arp"
SSHPORT="22"

# Logging configuration
LOG="LOG --log-level debug --log-tcp-sequence --log-tcp-options"
LOG="$LOG --log-ip-options"

# Rate limiting defaults
RLIMIT="-m limit --limit 3/s --limit-burst 8"

# Port ranges
PHIGH="1024:65535"
PSSH="1000:1023"

# Load required modules
"$MODPROBE" ip_conntrack_ftp
"$MODPROBE" ip_conntrack_irc

# ========================================================
# TCP/IP HARDENING
# ========================================================
print_section "Applying TCP/IP hardening..."

# IP Spoofing protection
for i in /proc/sys/net/ipv4/conf/*/rp_filter; do echo 1 > "$i"; done

# TCP/IP hardening
echo 1 > /proc/sys/net/ipv4/tcp_syncookies
echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
for i in /proc/sys/net/ipv4/conf/*/log_martians; do echo 1 > "$i"; done
echo 1 > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses

# Disable IP forwarding
for i in /proc/sys/net/ipv4/conf/*/accept_redirects; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/send_redirects; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/accept_source_route; do echo 0 > "$i"; done

# Disable multicast and proxy settings
for i in /proc/sys/net/ipv4/conf/*/mc_forwarding; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/proxy_arp; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/secure_redirects; do echo 1 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/bootp_relay; do echo 0 > "$i"; done

# ========================================================
# IPTABLES CONFIGURATION
# ========================================================
print_section "Configuring iptables firewall..."

# Initialize enhanced iptables configuration
"$IPTABLES" -P INPUT DROP
"$IPTABLES" -P FORWARD DROP
"$IPTABLES" -P OUTPUT ACCEPT  # Changed to ACCEPT for outbound

# Configure NAT/mangle tables
"$IPTABLES" -t nat -P PREROUTING ACCEPT
"$IPTABLES" -t nat -P OUTPUT ACCEPT
"$IPTABLES" -t nat -P POSTROUTING ACCEPT

"$IPTABLES" -t mangle -P PREROUTING ACCEPT
"$IPTABLES" -t mangle -P INPUT ACCEPT
"$IPTABLES" -t mangle -P FORWARD ACCEPT
"$IPTABLES" -t mangle -P OUTPUT ACCEPT
"$IPTABLES" -t mangle -P POSTROUTING ACCEPT

# Clean existing rules
"$IPTABLES" -F
"$IPTABLES" -t nat -F
"$IPTABLES" -t mangle -F
"$IPTABLES" -X
"$IPTABLES" -t nat -X
"$IPTABLES" -t mangle -X
"$IPTABLES" -Z
"$IPTABLES" -t nat -Z
"$IPTABLES" -t mangle -Z

# ========================================================
# CUSTOM CHAINS FOR DETAILED LOGGING
# ========================================================
print_section "Setting up logging chains..."

# Custom chains
"$IPTABLES" -N ACCEPTLOG
"$IPTABLES" -A ACCEPTLOG -j "$LOG" "$RLIMIT" --log-prefix "ACCEPT "
"$IPTABLES" -A ACCEPTLOG -j ACCEPT

"$IPTABLES" -N DROPLOG
"$IPTABLES" -A DROPLOG -j "$LOG" "$RLIMIT" --log-prefix "DROP "
"$IPTABLES" -A DROPLOG -j DROP

"$IPTABLES" -N REJECTLOG
"$IPTABLES" -A REJECTLOG -j "$LOG" "$RLIMIT" --log-prefix "REJECT "
"$IPTABLES" -A REJECTLOG -p tcp -j REJECT --reject-with tcp-reset
"$IPTABLES" -A REJECTLOG -j REJECT

"$IPTABLES" -N RELATED_ICMP
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type destination-unreachable -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type time-exceeded -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type parameter-problem -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -j DROPLOG

# ========================================================
# TRAFFIC RULES
# ========================================================
print_section "Configuring specific traffic rules..."

# Allow loopback
"$IPTABLES" -A INPUT -i lo -j ACCEPT
"$IPTABLES" -A OUTPUT -o lo -j ACCEPT

# PING rules with rate limiting
"$IPTABLES" -A INPUT -p icmp -m limit --limit 1/s --limit-burst 2 -j ACCEPT
"$IPTABLES" -A INPUT -p icmp -m limit --limit 1/s --limit-burst 2 -j LOG --log-prefix PING-DROP:
"$IPTABLES" -A INPUT -p icmp -j DROP
"$IPTABLES" -A OUTPUT -p icmp -j ACCEPT

# Block suspicious packets
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
"$IPTABLES" -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
"$IPTABLES" -A INPUT -p tcp -m conntrack --ctstate NEW -m limit --limit 60/s --limit-burst 20 -j ACCEPT

# Allow established connections
"$IPTABLES" -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
"$IPTABLES" -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# ========================================================
# OUTBOUND CONNECTION RULES
# ========================================================
print_section "Configuring outbound connection rules..."

# Allow essential outbound connections
"$IPTABLES" -A OUTPUT -m state --state NEW -p udp --dport 53 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 53 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 80 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 443 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 587 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 995 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport "$SSHPORT" -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 21 -j ACCEPT

# ========================================================
# TOR NETWORK RULES
# ========================================================
print_section "Allowing Tor network connections..."
"$IPTABLES" -A INPUT -p tcp --dport 9050 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 9051 -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9050 -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9051 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 9150 -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9150 -j ACCEPT

# ========================================================
# GITHUB AND DEVELOPER RULES
# ========================================================
print_section "Allowing GitHub and developer connections..."
"$IPTABLES" -A OUTPUT -p tcp --dport 22 -j ACCEPT  # Git SSH
"$IPTABLES" -A OUTPUT -p tcp --dport 9418 -j ACCEPT  # Git protocol
"$IPTABLES" -A OUTPUT -p tcp --dport 443 -j ACCEPT  # HTTPS
"$IPTABLES" -A INPUT -p tcp --sport 22 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --sport 9418 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --sport 443 -j ACCEPT

# ========================================================
# ESSENTIAL INBOUND SERVICES
# ========================================================
print_section "Configuring essential inbound services..."
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 80 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 443 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport "$SSHPORT" -j ACCEPT

# ========================================================
# P2P AND GAMING RULES
# ========================================================
print_section "Configuring P2P and gaming rules..."
"$IPTABLES" -A INPUT -p tcp --dport 6881:6889 -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 6881:6889 -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 27000:27100 -j ACCEPT  # Steam
"$IPTABLES" -A INPUT -p tcp --dport 27000:27100 -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 3478:3480 -j ACCEPT   # PlayStation/Xbox
"$IPTABLES" -A INPUT -p tcp --dport 3478:3480 -j ACCEPT

# Add Discord voice chat support
"$IPTABLES" -A INPUT -p udp --dport 50000:65535 -j ACCEPT  # Discord voice
"$IPTABLES" -A OUTPUT -p udp --dport 50000:65535 -j ACCEPT

# ========================================================
# DDOS PROTECTION
# ========================================================
print_section "Implementing DDoS protection..."
"$IPTABLES" -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 3 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --syn -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -m limit --limit 1/h -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL ALL -m limit --limit 1/h -j ACCEPT

# Add brute force protection for SSH
"$IPTABLES" -A INPUT -p tcp --dport "$SSHPORT" -m state --state NEW -m recent --set --name SSH
"$IPTABLES" -A INPUT -p tcp --dport "$SSHPORT" -m state --state NEW -m recent --update --seconds 60 --hitcount 4 --name SSH -j DROP

# ========================================================
# LOGGING CONFIGURATION
# ========================================================
print_section "Setting up connection logging..."
# Add logging for failed connection attempts
"$IPTABLES" -A INPUT -m limit --limit 5/min -j LOG --log-prefix "iptables_INPUT_denied: " --log-level 7

# Explicitly log and reject everything else
"$IPTABLES" -A INPUT -j REJECTLOG
"$IPTABLES" -A FORWARD -j REJECTLOG

# Save current iptables rules
iptables-save > /etc/iptables/rules.v4

# ========================================================
# DISABLE UNCOMMON NETWORK PROTOCOLS
# ========================================================
print_section "Disabling uncommon network protocols..."
cat >> /etc/modprobe.d/uncommon-net-protocols.conf << EOF
install dccp /bin/true
install sctp /bin/true
install rds /bin/true
install tipc /bin/true
install n-hdlc /bin/true
install ax25 /bin/true
install netrom /bin/true
install x25 /bin/true
install rose /bin/true
install decnet /bin/true
install econet /bin/true
install af_802154 /bin/true
install ipx /bin/true
install appletalk /bin/true
install psnap /bin/true
install p8023 /bin/true
install p8022 /bin/true
install can /bin/true
install atm /bin/true
EOF

# ========================================================
# DISABLE UNCOMMON FILESYSTEMS
# ========================================================
print_section "Disabling uncommon filesystems..."
cat >> /etc/modprobe.d/uncommon-filesystems.conf << EOF
install cramfs /bin/true
install freevxfs /bin/true
install jffs2 /bin/true
install hfs /bin/true
install hfsplus /bin/true
install squashfs /bin/true
install udf /bin/true
EOF

# ========================================================
# ADDITIONAL SECURITY FEATURES
# ========================================================
print_section "Adding additional security features..."

# Secure su by limiting to wheel group
if ! grep -q "auth required pam_wheel.so" /etc/pam.d/su; then
    echo "auth required pam_wheel.so use_uid" >> /etc/pam.d/su
fi

# Configure bash history for better forensics
cat >> /etc/profile.d/bash_history.sh << EOF
export HISTTIMEFORMAT="%F %T "
export HISTCONTROL=ignoredups
export HISTSIZE=1000
readonly HISTSIZE
readonly HISTFILE
readonly HISTFILESIZE
EOF
chmod +x /etc/profile.d/bash_history.sh

# Create login banner with legal warning
cat > /etc/issue << EOF
+---------------------------------------------------------------+
| WARNING: Unauthorized access to this system is prohibited.    |
| All connections are logged and monitored. Disconnect          |
| IMMEDIATELY if you are not an authorized user!                |
+---------------------------------------------------------------+
EOF

cp /etc/issue /etc/issue.net

# ========================================================
# APPLY HARDENED CONFIGURATION FILES
# ========================================================
print_section "Applying Hardened configuration files..."
apply_config "etc-aide-conf" "/etc/aide.conf"
apply_config "etc-bash-bashrc" "/etc/bash.bashrc"
apply_config "etc-crypttab" "/etc/crypttab"
apply_config "etc-default-passwd" "/etc/default/passwd"
apply_config "etc-dhclient-conf" "/etc/dhclient.conf"
apply_config "etc-hardening-wrapper-conf" "/etc/hardening-wrapper.conf"
apply_config "etc-iptables-ip6tables.rules" "/etc/iptables/ip6tables.rules"
apply_config "etc-iptables-iptables.rules" "/etc/iptables/iptables.rules"
apply_config "etc-issue" "/etc/issue"
apply_config "etc-issue-net" "/etc/issue.net"
apply_config "etc-locale-conf" "/etc/locale.conf"
apply_config "etc-locale-gen" "/etc/locale.gen"
apply_config "etc-modprobe-d-blacklist-firewire" "/etc/modprobe.d/blacklist-firewire"

# ========================================================
# CREATE SECURITY BACKUP
# ========================================================
print_section "Creating security configuration backup..."
BACKUP_DIR="/root/security_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -p /etc/ssh/sshd_config "$BACKUP_DIR/" 2>/dev/null
cp -p /etc/sysctl.conf "$BACKUP_DIR/"
cp -p /etc/security/limits.conf "$BACKUP_DIR/"
iptables-save > "$BACKUP_DIR/iptables_backup"

# ========================================================
# COMPLETION MESSAGE
# ========================================================
print_section "System hardening completed"
echo "Enhanced hardening configuration completed at $(date)"

exit 0
'

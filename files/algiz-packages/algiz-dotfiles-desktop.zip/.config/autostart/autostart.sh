#!/bin/bash

# Launch programs under mimalloc
MIMALLOC_LIB=/usr/lib/libmimalloc.so
export LD_PRELOAD="$MIMALLOC_LIB"

# Kill programs
for p in xfdesktop pipewire pipewire-pulse wireplumber redshift xfce-superkey gnome-keyring-daemon Thunar; do
    pkill -9 -u "$USER" "$p" || true
done

# Launch programs
(
    xfdesktop &
    chrt -f 80 pipewire &
    chrt -f 80 pipewire-pulse &
    (sleep 0.05; wireplumber &) 
    redshift -l geoclue2 -t 6500:5000 -b 1.0:1.0 -m randr -v &
    xfce-superkey &
    gnome-keyring-daemon &
    Thunar --daemon &
)

# Disable screensaver
xset -dpms s off s 0 0 || true

# Tauon Alt-Cache
(
    mkdir -p "$HOME/share/TauonMusicBox/storage"
    cp /usr/share/applications/tauonmb.desktop ~/.local/share/applications/ 2>/dev/null || true
    if ! grep -q "XDG_CACHE_HOME=\$HOME/share/TauonMusicBox/storage" ~/.local/share/applications/tauonmb.desktop 2>/dev/null; then
        sed -i 's|^Exec=.*|Exec=env XDG_CACHE_HOME=$HOME/share/TauonMusicBox/storage tauonmb %U|' ~/.local/share/applications/tauonmb.desktop
    fi
) &




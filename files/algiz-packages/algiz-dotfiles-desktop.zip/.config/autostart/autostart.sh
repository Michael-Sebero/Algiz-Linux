#!/bin/bash

# Launch programs normally
gnome-keyring-daemon || true

# Kill programs
for p in xfdesktop; do
    pkill -9 -u "$USER" "$p" || true
done

# Launch programs under mimalloc
MIMALLOC_LIB=/usr/lib/libmimalloc.so
export LD_PRELOAD="$MIMALLOC_LIB"
(
    xfdesktop &
    chrt -f 80 pipewire &
    chrt -f 80 pipewire-pulse &
    (sleep 0.05; wireplumber &) 
    redshift -l geoclue2 -t 6500:5000 -b 1.0:1.0 -m randr -v &
    xfce-superkey &
)

# Disable screensaver
xset -dpms s off s 0 0 || true

#!/bin/sh
# Set OMP_NUM_THREADS dynamically to the number of physical cores
if command -v lscpu >/dev/null 2>&1; then
  export OMP_NUM_THREADS="$(lscpu -b -p=Core,Socket | grep -v '^#' | sort -u | wc -l)"
elif [ -f /proc/cpuinfo ]; then
  export OMP_NUM_THREADS="$(grep -E "^core id|^physical id" /proc/cpuinfo | sort -u | wc -l | awk '{print int($1/2)}')"
fi

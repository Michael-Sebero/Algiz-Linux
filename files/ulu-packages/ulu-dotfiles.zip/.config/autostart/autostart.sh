#!/bin/bash

# Launch programs normally
eval $(gnome-keyring-daemon --start --components=secrets,ssh,pkcs11)
export SSH_AUTH_SOCK || true

# Kill programs
for p in xfdesktop; do
    pkill -9 -u "$USER" "$p" || true
done

# Launch programs under mimalloc
MIMALLOC_LIB=/usr/lib/libmimalloc.so
export LD_PRELOAD="$MIMALLOC_LIB"
(
    xfdesktop &
    redshift -l geoclue2 -t 6500:5000 -b 1.0:1.0 -m randr -v &
)

for attempt in $(seq 1 5); do
    pgrep -u "$USER" -x pipewire > /dev/null 2>&1 && break
    chrt -f 99 nice -n -20 pipewire &
    sleep 1
done
taskset -cp 4 $(pgrep -u "$USER" -x pipewire) 2>/dev/null || true

for attempt in $(seq 1 5); do
    pgrep -u "$USER" -x pipewire-pulse > /dev/null 2>&1 && break
    chrt -f 99 nice -n -20 pipewire-pulse &
    sleep 1
done
taskset -cp 4 $(pgrep -u "$USER" -x pipewire-pulse) 2>/dev/null || true

for attempt in $(seq 1 5); do
    pgrep -u "$USER" -x wireplumber > /dev/null 2>&1 && break
    chrt -f 99 nice -n -20 wireplumber &
    sleep 1
done
taskset -cp 4 $(pgrep -u "$USER" -x wireplumber) 2>/dev/null || true

# Disable screensaver
xset -dpms s off s 0 0 || true
